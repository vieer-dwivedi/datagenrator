from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service


def get_driver(url, headless):
    chrome_options = ChromeOptions()
    chrome_service = Service()
    chrome_options.add_argument("--window-size=1280x1696")
    if headless:
        chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(service=chrome_service, options=chrome_options)
    driver.get(url)
    return driver