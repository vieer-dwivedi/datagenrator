import logging


logging.basicConfig(level=logging.DEBUG,
                    format='%(message)s',
                    handlers=[logging.FileHandler('repots.log'),  
                              logging.StreamHandler()])