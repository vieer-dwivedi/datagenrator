import scrapper


if __name__ == "__main__":
    scrapper.scrapper("terraform-aws-modules")