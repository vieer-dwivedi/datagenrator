import driver as driver_creator
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time



driver = driver_creator.get_driver(f"https://registry.terraform.io/modules/terraform-aws-modules/vpc/aws/latest", headless=False)
version_button = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[1]/div/div/div[1]/div[1]/div/div[1]/button"))
)
version_button.click()
show_all_button = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "//button[contains(text(), 'Show All')]"))
)
show_all_button.click()
version_list_web = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[1]/div/div/div[1]/div[1]/div/div[2]/div"))
).find_elements(By.TAG_NAME, "a")
for versions in version_list_web:
    print(versions.text.strip(), versions.get_attribute("href"))