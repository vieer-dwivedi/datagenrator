import driver as driver_creator
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import traceback
import time
import json

page_links = {}
drive = {}
output = {}

def scrapper(namespace):
    driver = driver_creator.get_driver(f"https://registry.terraform.io/search/modules?namespace={namespace}", headless=True)
    services_links(driver)
    
    for service, link in page_links.items():
        try:
            # Get versions for each service
            get_versions(service, link, driver)
            
            # Process version data
            for version, link in drive.items():
                version_data(service, version, link, driver)

            # Save the output to a file
            with open(f'./dumps/{service}.json', 'w') as file:
                json.dump(output, file, indent=4)
            
            drive.clear()
            output.clear()

        except Exception as service_error:
            print(f"Skipping service {service} due to error: {service_error}")
            continue  # Skip to the next service

    driver.quit()

def get_versions(service, link, driver):
    print(f"Service: {service}, Link: {link}")
    driver.get(link)
    
    try:
        # Click version button
        version_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[1]/div/div/div[1]/div[1]/div/div[1]/button"))
        )
        version_button.click()
        
        # Click "Show All" button
        show_all_button = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//button[contains(text(), 'Show All')]"))
        )
        show_all_button.click()

        # Get version list
        version_list_web = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[1]/div/div/div[1]/div[1]/div/div[2]/div"))
        ).find_elements(By.TAG_NAME, "a")

        for version in version_list_web:
            text = version.text.strip()
            href = version.get_attribute("href")
            print(text, href)
            drive[text] = href

    except Exception as e:
        print(f"Skipping versions for service {service} due to error: {e}")
        raise e  # Allow this exception to be caught in the scrapper function

def version_data(service, version, link, driver):
    inputs_list = []
    outputs_list = []
    driver.get(link)

    try:
        # Handle input rows
        print(f"Checking inputs for service {service} version {version}...")
        inputs_table = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//h2[@id='inputs']//following-sibling::table"))
        )
        inputs_rows = inputs_table.find_elements(By.TAG_NAME, "tr")
        print(f"Found inputs table with {len(inputs_rows)} rows")

        inputs = {0: {"Name": ""}, 1: {"Description": ""}, 2: {"Type": ""}, 3: {"Default": ""}, 4: {"Required": ""}}
        for row in inputs_rows:
            cells = row.find_elements(By.TAG_NAME, "td")
            row_data = {list(inputs[index].keys())[0]: cells[index].text.strip() for index in range(len(cells)) if index in inputs}
            if any(row_data.values()):
                inputs_list.append(row_data)

    except Exception as e:
        print(f"Missing inputs for version {version} of service {service}. Skipping entire service.")
        raise e  # Skip the service entirely

    try:
        # Handle output rows
        print(f"Checking outputs for service {service} version {version}...")
        outputs_table = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//h2[@id='outputs']//following-sibling::table//following-sibling::tbody"))
        )
        outputs_rows = outputs_table.find_elements(By.TAG_NAME, "tr")
        print(f"Found outputs table with {len(outputs_rows)} rows")

        outputs = {0: {"Name": ""}, 1: {"Description": ""}}
        for row in outputs_rows:
            cells = row.find_elements(By.TAG_NAME, "td")
            row_data = {list(outputs[index].keys())[0]: cells[index].text.strip() for index in range(len(cells)) if index in outputs}
            if any(row_data.values()):
                outputs_list.append(row_data)

    except Exception as e:
        print(f"Missing outputs for version {version} of service {service}. Skipping entire service.")
        raise e  # Skip the service entirely

    if service not in output:
        output[service] = {}

    output[service][version] = {
        "inputs": inputs_list,
        "outputs": outputs_list
    }
    print(output)

def page_scrapper(driver):
    elements = WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".module-card .ember-view"))
    )
    for link in elements:
        href = link.get_attribute("href")
        title = link.find_element(By.XPATH, ".//span[@class='module-card-title-separator']/parent::*").text
        separator = link.find_element(By.CLASS_NAME, "module-card-title-separator").text
        page_links[title.split(separator, 1)[1].strip()] = href

def services_links(driver):
    while True:
        try:
            page_scrapper(driver)
            next_button = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "a.ember-view.pagination-nav-button.pagination-nav-button-next"))
            )
            if "disabled" in next_button.get_attribute("class"):
                break
            driver.execute_script("arguments[0].click();", next_button)
            time.sleep(1)

        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            traceback.print_exc()
            break
